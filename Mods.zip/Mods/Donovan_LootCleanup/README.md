# Donovan LootCleanup

## 7 Days 2 Die Modlet

Destroys garbage and birdnests after looting, to clean up the environment.

- Birdnests
- Garbage
