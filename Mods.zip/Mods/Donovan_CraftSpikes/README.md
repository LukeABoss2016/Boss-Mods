# Donovan CraftSpikes

## 7 Days 2 Die Modlet

This small modlet adds the wood and iron Log Spikes back into the game as a craftable item.
