This is V1.02 of Boss Mod.

Open your 7 days folder. Make sure there is No Mods folder in it. If there is delet it, and drage and drop my Mods folder in.
That easy. Enjoy.

I will be adding more things as time goes on. If you have any input or feed back please leave it on my discord. FYI I am a nood at modding.
Link to my Discord   https://discord.gg/4yZeUkX

