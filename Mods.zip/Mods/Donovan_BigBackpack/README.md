# Donovan Big Backpack

## 7 Days 2 Die Modlet

Increases the size of the player inventory to 60
